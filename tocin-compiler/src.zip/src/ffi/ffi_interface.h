#pragma once

#include <string>
#include <memory>
#include <variant>
#include <vector>
#include "../ast/ast.h"

namespace ffi {

    class FFIValue {
    public:
        using ValueType = std::variant<
            int64_t,
            double,
            bool,
            std::string,
            std::nullptr_t
        >;

        FFIValue() : value(nullptr) {}
        FFIValue(ValueType val) : value(std::move(val)) {}

        template<typename T>
        T as() const {
            return std::get<T>(value);
        }

        bool isNull() const { return std::holds_alternative<std::nullptr_t>(value); }

    private:
        ValueType value;
    };

    class FFIInterface {
    public:
        virtual ~FFIInterface() = default;

        // JavaScript integration
        virtual FFIValue callJavaScript(const std::string& functionName,
            const std::vector<FFIValue>& args) = 0;

        // Python integration
        virtual FFIValue callPython(const std::string& moduleName,
            const std::string& functionName,
            const std::vector<FFIValue>& args) = 0;

        // C++ integration
        virtual FFIValue callCpp(const std::string& functionName,
            const std::vector<FFIValue>& args) = 0;
    };

} // namespace ffi
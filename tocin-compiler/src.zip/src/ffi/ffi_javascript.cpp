#pragma once

#include "ffi_javascript.h"
#include <stdexcept>

namespace ffi {

    JavaScriptFFI::JavaScriptFFI() {
        v8::V8::InitializeICUDefaultLocation(nullptr);
        v8::V8::InitializeExternalStartupData(nullptr);
        v8::V8::Initialize();

        v8::Isolate::CreateParams create_params;
        create_params.array_buffer_allocator =
            v8::ArrayBuffer::Allocator::NewDefaultAllocator();
        isolate = v8::Isolate::New(create_params);

        v8::Isolate::Scope isolate_scope(isolate);
        v8::HandleScope handle_scope(isolate);

        auto context = v8::Context::New(isolate);
        this->context.Reset(isolate, context);
    }

    JavaScriptFFI::~JavaScriptFFI() {
        context.Reset();
        isolate->Dispose();
        v8::V8::Dispose();
    }

    FFIValue JavaScriptFFI::callJavaScript(
        const std::string& functionName,
        const std::vector<FFIValue>& args) {

        v8::Isolate::Scope isolate_scope(isolate);
        v8::HandleScope handle_scope(isolate);

        auto context = v8::Local<v8::Context>::New(isolate, this->context);
        v8::Context::Scope context_scope(context);

        try {
            // Get the function from global scope
            auto global = context->Global();
            auto funcValue = global->Get(context,
                v8::String::NewFromUtf8(isolate, functionName.c_str())
                .ToLocalChecked());

            if (funcValue.IsEmpty() || !funcValue.ToLocalChecked()->IsFunction()) {
                throw std::runtime_error("JavaScript function not found: " + functionName);
            }

            auto func = v8::Local<v8::Function>::Cast(funcValue.ToLocalChecked());

            // Convert arguments
            std::vector<v8::Local<v8::Value>> v8Args;
            v8Args.reserve(args.size());

            for (const auto& arg : args) {
                v8Args.push_back(convertToV8Value(arg));
            }

            // Call the function
            auto result = func->Call(context, global, v8Args.size(), v8Args.data());

            if (result.IsEmpty()) {
                throw std::runtime_error("JavaScript function call failed");
            }

            return convertFromV8Value(result.ToLocalChecked());

        }
        catch (const std::exception& e) {
            throw std::runtime_error("JavaScript FFI error: " + std::string(e.what()));
        }
    }

    v8::Local<v8::Value> JavaScriptFFI::convertToV8Value(const FFIValue& value) {
        // Implementation of value conversion from Tocin to JavaScript
        // This is a simplified version - expand based on your needs
        if (value.isNull()) {
            return v8::Null(isolate);
        }

        try {
            if (auto intVal = std::get_if<int64_t>(&value)) {
                return v8::Number::New(isolate, static_cast<double>(*intVal));
            }
            if (auto doubleVal = std::get_if<double>(&value)) {
                return v8::Number::New(isolate, *doubleVal);
            }
            if (auto boolVal = std::get_if<bool>(&value)) {
                return v8::Boolean::New(isolate, *boolVal);
            }
            if (auto strVal = std::get_if<std::string>(&value)) {
                return v8::String::NewFromUtf8(isolate, strVal->c_str())
                    .ToLocalChecked();
            }
        }
        catch (const std::exception& e) {
            throw std::runtime_error("Failed to convert value to JavaScript: " +
                std::string(e.what()));
        }

        throw std::runtime_error("Unsupported value type for JavaScript conversion");
    }

    FFIValue JavaScriptFFI::convertFromV8Value(v8::Local<v8::Value> value) {
        // Implementation of value conversion from JavaScript to Tocin
        // This is a simplified version - expand based on your needs
        if (value->IsNull() || value->IsUndefined()) {
            return FFIValue();
        }

        try {
            if (value->IsNumber()) {
                return FFIValue(value->NumberValue(isolate->GetCurrentContext())
                    .ToChecked());
            }
            if (value->IsBoolean()) {
                return FFIValue(value->BooleanValue(isolate));
            }
            if (value->IsString()) {
                v8::String::Utf8Value str(isolate, value);
                return FFIValue(std::string(*str));
            }
        }
        catch (const std::exception& e) {
            throw std::runtime_error("Failed to convert value from JavaScript: " +
                std::string(e.what()));
        }

        throw std::runtime_error("Unsupported JavaScript value type");
    }

} // namespace ffi
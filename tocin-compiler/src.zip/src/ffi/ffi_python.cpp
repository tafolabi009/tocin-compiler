#include "ffi_python.h"
#include <stdexcept>

namespace ffi {

    PythonFFI::PythonFFI() {
        Py_Initialize();
    }

    PythonFFI::~PythonFFI() {
        Py_Finalize();
    }

    FFIValue PythonFFI::callPython(
        const std::string& moduleName,
        const std::string& functionName,
        const std::vector<FFIValue>& args) {

        try {
            // Import the Python module
            PyObject* pModule = PyImport_ImportModule(moduleName.c_str());
            if (!pModule) {
                throw std::runtime_error("Failed to load Python module: " + moduleName);
            }

            // Get the function object
            PyObject* pFunc = PyObject_GetAttrString(pModule, functionName.c_str());
            if (!pFunc || !PyCallable_Check(pFunc)) {
                Py_XDECREF(pModule);
                throw std::runtime_error("Python function not found: " + functionName);
            }

            // Create arguments tuple
            PyObject* pArgs = PyTuple_New(args.size());

            for (size_t i = 0; i < args.size(); ++i) {
                PyObject* pValue = convertToPyObject(args[i]);
                PyTuple_SetItem(pArgs, i, pValue);
            }

            // Call the function
            PyObject* pResult = PyObject_CallObject(pFunc, pArgs);

            // Clean up
            Py_DECREF(pArgs);
            Py_DECREF(pFunc);
            Py_DECREF(pModule);

            if (!pResult) {
                PyErr_Print();
                throw std::runtime_error("Python function call failed");
            }

            // Convert result
            FFIValue result = convertFromPyObject(pResult);
            Py_DECREF(pResult);

            return result;

        }
        catch (const std::exception& e) {
            throw std::runtime_error("Python FFI error: " + std::string(e.what()));
        }
    }

    PyObject* PythonFFI::convertToPyObject(const FFIValue& value) {
        if (value.isNull()) {
            Py_RETURN_NONE;
        }

        try {
            if (auto intVal = std::get_if<int64_t>(&value)) {
                return PyLong_FromLongLong(*intVal);
            }
            if (auto doubleVal = std::get_if<double>(&value)) {
                return PyFloat_FromDouble(*doubleVal);
            }
            if (auto boolVal = std::get_if<bool>(&value)) {
                return PyBool_FromLong(*boolVal);
            }
            if (auto strVal = std::get_if<std::string>(&value)) {
                return PyUnicode_FromString(strVal->c_str());
            }
        }
        catch (const std::exception& e) {
            throw std::runtime_error("Failed to convert value to Python: " +
                std::string(e.what()));
        }

        throw std::runtime_error("Unsupported value type for Python conversion");
    }

    FFIValue PythonFFI::convertFromPyObject(PyObject* obj) {
        if (obj == Py_None) {
            return FFIValue();
        }

        try {
            if (PyLong_Check(obj)) {
                return FFIValue(PyLong_AsLongLong(obj));
            }
            if (PyFloat_Check(obj)) {
                return FFIValue(PyFloat_AsDouble(obj));
            }
            if (PyBool_Check(obj)) {
                return FFIValue(obj == Py_True);
            }
            if (PyUnicode_Check(obj)) {
                return FFIValue(std::string(PyUnicode_AsUTF8(obj)));
            }
        }
        catch (const std::exception& e) {
            throw std::runtime_error("Failed to convert value from Python: " +
                std::string(e.what()));
        }

        throw std::runtime_error("Unsupported Python value type");
    }

} // namespace ffi
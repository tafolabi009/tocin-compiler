#include "ffi_cpp.h"
#include <stdexcept>

namespace ffi {

    CppFFI::CppFFI() {
        // Register some built-in functions
        registerFunction("print", [](const std::vector<FFIValue>& args) -> FFIValue {
            for (const auto& arg : args) {
                if (auto strVal = std::get_if<std::string>(&arg)) {
                    std::cout << *strVal;
                }
                else if (auto intVal = std::get_if<int64_t>(&arg)) {
                    std::cout << *intVal;
                }
                else if (auto doubleVal = std::get_if<double>(&arg)) {
                    std::cout << *doubleVal;
                }
                else if (auto boolVal = std::get_if<bool>(&arg)) {
                    std::cout << (*boolVal ? "true" : "false");
                }
                else {
                    std::cout << "null";
                }
            }
            std::cout << std::endl;
            return FFIValue();
            });
    }

    FFIValue CppFFI::callCpp(
        const std::string& functionName,
        const std::vector<FFIValue>& args) {

        try {
            auto it = functions.find(functionName);
            if (it == functions.end()) {
                throw std::runtime_error("C++ function not found: " + functionName);
            }

            return it->second(args);

        }
        catch (const std::exception& e) {
            throw std::runtime_error("C++ FFI error: " + std::string(e.what()));
        }
    }

    void CppFFI::registerFunction(const std::string& name, CppFunction func) {
        functions[name] = std::move(func);
    }

    // These are no-op implementations since this is the C++ FFI
    FFIValue CppFFI::callJavaScript(const std::string& functionName,
        const std::vector<FFIValue>& args) {
        throw std::runtime_error("JavaScript calls not supported in C++ FFI");
    }

    FFIValue CppFFI::callPython(const std::string& moduleName,
        const std::string& functionName,
        const std::vector<FFIValue>& args) {
        throw std::runtime_error("Python calls not supported in C++ FFI");
    }

} // namespace ffi
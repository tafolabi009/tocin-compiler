// tocin-compiler/src/main.cpp
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <memory>
#include "lexer/lexer.h"
#include "parser/parser.h"
#include "type/type_checker.h"
#include "codegen/ir_generator.h"

void printUsage() {
    std::cout << "Usage: tocinc [options] input_file.to\n";
    std::cout << "Options:\n";
    std::cout << "  --output, -o <file>  Specify output file\n";
    std::cout << "  --help, -h           Display this help message\n";
}

int main(int argc, char** argv) {
    std::cout << "Tocin Compiler v0.1.0\n";

    if (argc < 2) {
        printUsage();
        return 1;
    }

    std::string inputFile;
    std::string outputFile = "a.out";

    // Parse command line arguments
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") {
            printUsage();
            return 0;
        }
        else if (arg == "--output" || arg == "-o") {
            if (i + 1 < argc) {
                outputFile = argv[++i];
            }
            else {
                std::cerr << "Error: Output file not specified\n";
                return 1;
            }
        }
        else if (arg[0] != '-') {
            inputFile = arg;
        }
    }

    if (inputFile.empty()) {
        std::cerr << "Error: No input file specified\n";
        return 1;
    }

    // Read input file
    std::ifstream file(inputFile);
    if (!file.is_open()) {
        std::cerr << "Error: Could not open file " << inputFile << "\n";
        return 1;
    }

    std::string sourceCode((std::istreambuf_iterator<char>(file)),
        std::istreambuf_iterator<char>());
    file.close();

    // In main.cpp, modify the compilation pipeline:
    try {
        CompilationContext context(inputFile);

        // Configure compilation options
        if (optimizationLevel > 0) {
            context.enableOptimizations(optimizationLevel);
        }
        if (debugInfo) {
            context.enableDebugInfo();
        }

        // Read source file
        std::ifstream file(inputFile);
        if (!file.is_open()) {
            context.errorHandler->reportError(
                "Could not open file", inputFile, 0, 0, error::ErrorSeverity::FATAL);
            return 1;
        }

        context.sourceCode = std::string(
            (std::istreambuf_iterator<char>(file)),
            std::istreambuf_iterator<char>()
        );
        file.close();

        // Compilation pipeline
        auto lexer = std::make_unique<Lexer>(context.sourceCode, inputFile);
        auto tokens = lexer->tokenize();

        auto parser = std::make_unique<Parser>(tokens, context.errorHandler);
        auto ast = parser->parse();

        if (context.hasErrors()) {
            return 1;
        }

        auto typeChecker = std::make_unique<TypeChecker>(context);
        typeChecker->check(ast);

        if (context.hasErrors()) {
            return 1;
        }

        auto irGenerator = std::make_unique<IRGenerator>(context);
        irGenerator->generate(ast, outputFile);

        if (!context.hasErrors()) {
            std::cout << "Successfully compiled " << inputFile << " to " << outputFile << "\n";
            return 0;
        }

        return 1;
    }
    catch (const std::exception& e) {
        std::cerr << "Compilation failed: " << e.what() << "\n";
        return 1;
    }

    return 0;
}